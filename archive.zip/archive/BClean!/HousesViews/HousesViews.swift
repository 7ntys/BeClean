//
//  HousesViews.swift
//  BClean!
//
//  Created by Julien Le ber on 02/02/2023.
//

import SwiftUI

struct HousesViews: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct HousesViews_Previews: PreviewProvider {
    static var previews: some View {
        HousesViews()
    }
}
