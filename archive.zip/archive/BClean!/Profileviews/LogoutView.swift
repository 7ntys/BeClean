//
//  LogoutView.swift
//  BClean!
//
//  Created by Julien Le ber on 03/02/2023.
//

import SwiftUI
import Firebase
struct LogoutView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LogoutView_Previews: PreviewProvider {
    static var previews: some View {
        LogoutView()
    }
}
