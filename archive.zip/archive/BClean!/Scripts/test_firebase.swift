//
//  test_firebase.swift
//  BClean!
//
//  Created by Julien Le ber on 07/04/2023.
//

import Foundation
import SwiftUi
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth

func get_users(){
    let user_db = db.collection("users")
    
}
